<?php
/**
 * Main Template File
 *
 * @package Ullapara_Press_Club
 */

get_header();
?>

<div id="root">
  <!-- React App Mount Point -->
</div>

<?php
get_footer();
